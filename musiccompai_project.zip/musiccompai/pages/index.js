export default function Home() {
  return (
    <div style={{padding: 20}}>
      <h1>MusicCompAi 3.0</h1>
      <p>Plataforma de arranjos musicais com IA</p>
    </div>
  );
}