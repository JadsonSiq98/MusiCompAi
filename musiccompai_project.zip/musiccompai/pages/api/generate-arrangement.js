export default function handler(req, res) {
  const { style, instruments } = req.body;

  res.status(200).json({
    message: "Arranjo gerado com sucesso",
    style,
    instruments
  });
}