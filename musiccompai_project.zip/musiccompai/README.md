# MusicCompAi 3.0

Projeto pronto para deploy na Vercel.

## Rodar local:
npm install
npm run dev

## Deploy:
https://vercel.com
